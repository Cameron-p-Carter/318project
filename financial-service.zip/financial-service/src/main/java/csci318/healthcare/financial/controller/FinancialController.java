package csci318.healthcare.financial.controller;

import csci318.healthcare.financial.entity.Invoice;
import csci318.healthcare.financial.service.FinancialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/financial")
public class FinancialController {

    @Autowired
    private FinancialService financialService;

    //create invoice (accepts JSON invoice)
    @PostMapping("/invoice")
    public Invoice createInvoice(@RequestBody Invoice invoice) {
        return financialService.createInvoice(invoice);
    }

    //create invoice using query params (alternative)
    @PostMapping("/invoice/create")
    public Invoice createInvoiceParams(@RequestParam Long appointmentId,
                                       @RequestParam Long patientId,
                                       @RequestParam String patientName,
                                       @RequestParam Double amount) {
        return financialService.createInvoice(appointmentId, patientId, patientName, amount);
    }

    //get invoices for a patient
    @GetMapping("/invoices/{patientId}")
    public List<Invoice> getInvoicesByPatient(@PathVariable Long patientId) {
        return financialService.getInvoicesByPatientId(patientId);
    }

    //claim insurance
    @PostMapping("/invoice/claim/{invoiceId}")
    public void claimInsurance(@PathVariable Long invoiceId) {
        financialService.claimInsurance(invoiceId);
    }

    //mark paid
    @PostMapping("/invoice/pay/{invoiceId}")
    public void markPaid(@PathVariable Long invoiceId) {
        financialService.markPaid(invoiceId);
    }
}
