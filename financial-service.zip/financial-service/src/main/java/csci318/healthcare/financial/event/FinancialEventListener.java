package csci318.healthcare.financial.event;

import csci318.healthcare.financial.entity.Invoice;
import csci318.healthcare.financial.service.FinancialService;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.function.Consumer;

@Component
public class FinancialEventListener {

    private final FinancialService service;

    public FinancialEventListener(FinancialService service) {
        this.service = service;
    }

    @Bean
    public Consumer<String> appointmentEvents() {
        return message -> {
            try {
                // expected: "101,201,John Doe,150.0"
                String[] parts = message.split(",");
                Long appointmentId = Long.parseLong(parts[0].trim());
                Long patientId = Long.parseLong(parts[1].trim());
                String patientName = parts[2].trim();
                Double amount = Double.parseDouble(parts[3].trim());

                Invoice invoice = service.createInvoice(appointmentId, patientId, patientName, amount);
                System.out.println("Processed appointment event -> created invoice id: " + invoice.getId());
            } catch (Exception e) {
                System.err.println("Failed to process appointment event: " + e.getMessage());
            }
        };
    }
}
