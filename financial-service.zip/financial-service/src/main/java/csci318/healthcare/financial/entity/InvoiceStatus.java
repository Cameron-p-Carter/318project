package csci318.healthcare.financial.entity;

public enum InvoiceStatus {
    PENDING,
    CLAIMED,
    PAID
}
