package csci318.healthcare.financial.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "invoices")
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long appointmentId;
    private Long patientId;
    private String patientName;
    private Double amount;

    @Enumerated(EnumType.STRING)
    private InvoiceStatus status = InvoiceStatus.PENDING;

    private boolean paid = false;
    private boolean insuranceClaimed = false;

    public Invoice() {}

    public Invoice(Long appointmentId, Long patientId, String patientName, Double amount) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.patientName = patientName;
        this.amount = amount;
        this.status = InvoiceStatus.PENDING;
    }

    //getters and setters
    public Long getId() { return id; }

    public Long getAppointmentId() { return appointmentId; }
    public void setAppointmentId(Long appointmentId) { this.appointmentId = appointmentId; }

    public Long getPatientId() { return patientId; }
    public void setPatientId(Long patientId) { this.patientId = patientId; }

    public String getPatientName() { return patientName; }
    public void setPatientName(String patientName) { this.patientName = patientName; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public InvoiceStatus getStatus() { return status; }
    public void setStatus(InvoiceStatus status) { this.status = status; }

    public boolean isPaid() { return paid; }
    public void setPaid(boolean paid) { this.paid = paid; }

    public boolean isInsuranceClaimed() { return insuranceClaimed; }
    public void setInsuranceClaimed(boolean insuranceClaimed) { this.insuranceClaimed = insuranceClaimed; }

    public void markPaid() {
        this.paid = true;
        this.status = InvoiceStatus.PAID;
    }

    public void claimInsurance() {
        this.insuranceClaimed = true;
        this.status = InvoiceStatus.CLAIMED;
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "id=" + id +
                ", appointmentId=" + appointmentId +
                ", patientId=" + patientId +
                ", patientName='" + patientName + '\'' +
                ", amount=" + amount +
                ", status=" + status +
                ", paid=" + paid +
                ", insuranceClaimed=" + insuranceClaimed +
                '}';
    }
}
