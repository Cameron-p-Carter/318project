package csci318.healthcare.financial.service;

import csci318.healthcare.financial.entity.Invoice;
import csci318.healthcare.financial.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FinancialService {

    private final InvoiceRepository repository;

    public FinancialService(InvoiceRepository repository) {
        this.repository = repository;
    }

    //accept an Invoice object and persist
    public Invoice createInvoice(Invoice invoice) {
        return repository.save(invoice);
    }
	

    public Invoice createInvoice(Long appointmentId, Long patientId, String patientName, Double amount) {
        Invoice invoice = new Invoice(appointmentId, patientId, patientName, amount);
        return repository.save(invoice);
    }

    //view invoices by patient ID function
    public List<Invoice> getInvoicesByPatientId(Long patientId) {
        return repository.findByPatientId(patientId);
    }

    //mark invoice as paid function
    public void markPaid(Long invoiceId) {
        Optional<Invoice> maybe = repository.findById(invoiceId);
        maybe.ifPresent(inv -> {
            inv.markPaid();
            repository.save(inv);
        });
    }

    //claim insurance function
    public void claimInsurance(Long invoiceId) {
        Optional<Invoice> maybe = repository.findById(invoiceId);
        maybe.ifPresent(inv -> {
            inv.claimInsurance();
            repository.save(inv);
        });
    }

    //CLI printing
    public void printInvoices(List<Invoice> invoices) {
        if (invoices.isEmpty()) {
            System.out.println("No invoices found.");
            return;
        }
        invoices.forEach(inv -> {
            System.out.println("Invoice ID: " + inv.getId());
            System.out.println("  Appointment ID: " + inv.getAppointmentId());
            System.out.println("  Patient ID: " + inv.getPatientId());
            System.out.println("  Patient Name: " + inv.getPatientName());
            System.out.println("  Amount: " + inv.getAmount());
            System.out.println("  Status: " + inv.getStatus());
            System.out.println("  Paid: " + inv.isPaid());
            System.out.println("  Insurance Claimed: " + inv.isInsuranceClaimed());
            System.out.println("-------------------------------");
        });
    }
}
