package csci318.healthcare.financial;

import csci318.healthcare.financial.entity.Invoice;
import csci318.healthcare.financial.service.FinancialService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class FinancialServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinancialServiceApplication.class, args);
    }

    @Bean
    public CommandLineRunner cliRunner(FinancialService financialService) {
        return args -> {
            Scanner scanner = new Scanner(System.in);
            boolean running = true;

            System.out.println("=== Welcome to the Financial Service CLI ===");

            while (running) {
                System.out.println("\nChoose an option:");
                System.out.println("1. View invoices by patient ID");
                System.out.println("2. Claim insurance for an invoice");
                System.out.println("3. Mark an invoice as paid");
                System.out.println("4. Exit");
                System.out.print("Enter choice: ");

                String input = scanner.nextLine();
                switch (input) {
                    case "1":
                        System.out.print("Enter patient ID: ");
                        Long patientId = Long.parseLong(scanner.nextLine());
                        List<Invoice> invoices = financialService.getInvoicesByPatientId(patientId);
                        financialService.printInvoices(invoices);
                        break;

                    case "2":
                        System.out.print("Enter invoice ID to claim insurance: ");
                        Long claimId = Long.parseLong(scanner.nextLine());
                        financialService.claimInsurance(claimId);
                        System.out.println("Invoice marked as insurance claimed.");
                        break;

                    case "3":
                        System.out.print("Enter invoice ID to mark as paid: ");
                        Long payId = Long.parseLong(scanner.nextLine());
                        financialService.markPaid(payId);
                        System.out.println("Invoice marked as paid.");
                        break;

                    case "4":
                        System.out.println("Exiting CLI. Goodbye!");
                        running = false;
                        break;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            }

            scanner.close();
        };
    }
}
