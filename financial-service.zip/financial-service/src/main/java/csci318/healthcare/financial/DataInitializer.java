package csci318.healthcare.financial;

import csci318.healthcare.financial.service.FinancialService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.File;

@Component
public class DataInitializer implements CommandLineRunner {

    private final FinancialService service;

    public DataInitializer(FinancialService service) {
        this.service = service;
    }

    @Override
    public void run(String... args) {
        //check if the data file exists
        File dbFile = new File("financial-data.json"); // Replace with your actual data file
        if (!dbFile.exists()) {
            //only create invoices if data file does not exist
            service.createInvoice(1L, 1L, "Patient1", 100.0);
            service.createInvoice(2L, 2L, "Patient2", 200.0);
            service.createInvoice(3L, 3L, "Patient1", 150.0);
            System.out.println("Initialized invoices.");
        } else {
            System.out.println("Invoices already initialized. Skipping creation.");
        }
    }
}
